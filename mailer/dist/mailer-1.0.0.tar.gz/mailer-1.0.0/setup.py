from distutils.core import setup

setup(
	name	= 'mailer',
	version	= '1.0.0',
	py_modules	= ['mailer'],
	author	= 'Devil',
	author_email	= 'harshitanand94@gmail.com',
	description	= 'Simple email sender',
     )
